<?php

class SbbolException extends Exception
{

}