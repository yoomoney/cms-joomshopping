<?php
namespace YooMoney\Model;

use Exception;

class SbbolException extends Exception
{

}